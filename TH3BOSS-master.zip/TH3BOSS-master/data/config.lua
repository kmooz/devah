do local _ = {
  admins = {},
  disabled_channels = {},
  enabled_plugins = {
    "banhammer",
    "groupmanager",
    "msg-checks",
    "plugins",
    "tools",
    "me",
    "addreplay",
    "deleall"
  },
  info_text = "📌¦ Welcome My Dear\n\nTH3BOSS V13 \nFor More Information Subscribe To The Channel @llDEV1ll \n https://github.com/moody2020/TH3BOSS\n\n📌¦ Dev @TH3BOSS\n\n📌¦ Dev Bot @ll60Kllbot\n\n📌¦ Channel @llDEV1ll ",
  moderation = {
    data = "./data/moderation.json"
  },
  sudo_users = {
    60809019
  }
}
return _
end
